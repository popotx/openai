import akka.actor.ActorSystem
import akka.http.scaladsl.Http
import akka.http.scaladsl.model._
import akka.http.scaladsl.model.headers._
import akka.stream.ActorMaterializer
import scala.concurrent.duration._
import scala.concurrent.ExecutionContext.Implicits.global

object BurgersClient extends App {
  implicit val system = ActorSystem()
  implicit val materializer = ActorMaterializer()

  val apiKeyHeader = RawHeader("X-Rapidapi-Key", "d9b24c1978msha4f5885d176c64dp15fbd5jsn5d20eb1bac18")
  val apiHostHeader = RawHeader("X-Rapidapi-Host", "free-nba.p.rapidapi.com")
  val headers = List(apiKeyHeader, apiHostHeader)

  val request = HttpRequest(
    HttpMethods.GET,
    uri = "https://free-nba.p.rapidapi.com/players/9",
    headers = headers
  )

  val responseF = Http().singleRequest(request)

  responseF.map { response =>
    if (response.status.isSuccess()) {
      response.entity.toStrict(10.seconds).map(_.data.utf8String).foreach(println)
    } else {
      println(s"Request failed with status ${response.status}")
      response.discardEntityBytes()
    }
  }.onComplete(_ => system.terminate())
}
